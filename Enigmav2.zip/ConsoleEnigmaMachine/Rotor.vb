﻿Public Class Rotor
	Public ReadOnly mappings As New Dictionary(Of Char, Char)
	Public ReadOnly notches() As Char
	Private _offset As Integer = 0
	Public hasContactIssues As Boolean = False

	Public Property offset() As Integer
		Get
			Return _offset
		End Get
		Set(ByVal value As Integer)
			_offset = value
		End Set
	End Property

	Public Sub New(ByRef mappings As Dictionary(Of Char, Char), ByVal notches() As Char)
		'' Initialises a new rotor class instance using a dictionary containing
		'' the starting character mappings to apply when encrypting.
		Me.mappings = mappings
		Me.notches = notches
	End Sub


	Public Sub Map(ByVal char1 As Char, ByVal char2 As Char)
		'' Maps the encryption of Char1 to Char2.
		Me.mappings(char1) = char2
	End Sub

	Public Sub Rotate()
		'' Rotates the rotor once. Essentially shifts the mapping destinations
		'' forward by one position.
		'' The offset is increased by one unless the rotor has completed a full
		'' rotation, in which case it is reset to 0.

		Dim MappingSources(mappings.Keys.Count - 1) As Char
		Dim MappingDestinations(mappings.Values.Count - 1) As Char

		mappings.Keys.CopyTo(MappingSources, 0)
		mappings.Values.CopyTo(MappingDestinations, 0)


		Dim FirstDestination As Char = MappingDestinations(0)
		' Use the destination of the mapping one step ahead.
		For i As Integer = 0 To MappingDestinations.Count - 2
			Me.Map(MappingSources(i), MappingDestinations(i + 1))
		Next
		Me.Map(MappingSources.Last(), FirstDestination)

		Me.offset = (Me.offset + 1) Mod Me.mappings.Count

	End Sub

	''' <summary>
	''' Encrypts a character using this rotor's character mappings.
	''' Non-letter characters are returned unchanged.
	''' </summary>
	''' <param name="Char1">The character to encrypt</param>
	''' <returns>The encrypted character</returns>
	''' During encryption, you could check:

	Public Function StandardEncrypt(ByVal char1 As Char) As Char
		' Simulate intermittent contact issues (only if flag is set)
		If hasContactIssues AndAlso New Random().Next(100) < 5 Then ' 5% chance of error
			' Either return wrong character or original character
			Dim availableChars As Char() = Me.mappings.Keys.ToArray()
			Return availableChars(New Random().Next(availableChars.Length))
		End If

		'' Encrypts the character using this rotor's character mappings.
		If Not Char.IsLetter(char1) Then
			Return char1
		End If

		If Me.mappings.ContainsKey(char1) Then
			Return Me.mappings(char1)
		End If

		Throw New TranslationException("Could not map " & char1 & " to any character.")
	End Function


	Public Function ReflectEncrypt(ByVal char1 As Char) As Char
		'' Encrypts the character by passing it through this rotor's character
		'' mappings backwards.
		If Not Char.IsLetter(char1) Then
			Return char1
		End If

		For Each Pair As KeyValuePair(Of Char, Char) In Me.mappings
			If Pair.Value = char1 Then
				Return Pair.Key
			End If
		Next

		Throw New TranslationException("Could not map " & char1 & " to any character.")
	End Function

	''' <summary>
	''' Determines whether the specified character can be encrypted.
	''' </summary>
	Public Shared Function CanEncrypt(ByVal chr As Char) As Boolean
		Return Char.IsLetter(chr)
	End Function

End Class

Class TranslationException
	Inherits Exception

	Public Sub New()
	End Sub

	Public Sub New(ByVal message As String)
		MyBase.New(message)
	End Sub

	Public Sub New(ByVal message As String, ByVal innerException As Exception)
		MyBase.New(message, innerException)
	End Sub

End Class